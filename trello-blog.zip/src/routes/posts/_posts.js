// Ordinarily, you'd generate this data from markdown files in your
// repo, or fetch them from a database of some kind. But in order to
// avoid unnecessary dependencies in the starter template, and in the
// service of obviousness, we're just going to leave it here.

import fetch from "node-fetch";

// This file is called `_posts.js` rather than `posts.js`, because
// we don't want to create an `/blog/posts` route — the leading
// underscore tells Sapper not to do that.

let data = {};

let trello = async function getPosts() {
  const res = await fetch(
    `https://api.trello.com/1/lists/5f538d3a842e0a3b6ce9f259/cards?key=17d6c650cba87298007d28272969454e&token=b4476a360414a732dd2b2badae220dca1c6ec3bbe9e8d53d8583c75258c5667b`
  );
  data = await res.json();
  return (data = data.map((e) => {

    const months = ["jan", "feb", "mar","apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
    let posted_date = new Date(e.dateLastActivity)
    let formatted_date = `${posted_date.getDate()} ${months[posted_date.getMonth()]} ${posted_date.getFullYear()}`
    let tags = e.labels.map(e=>{
      return {
        name:e.name,
        color:e.color
      }
    })

    return { title: e.name, slug: e.name.toLowerCase().replace(/[^\w ]+/g,'').replace(/ +/g,'-'), desc: e.desc, image:e.cover.scaled,time:formatted_date,tags };
  }));
};

export default trello;
